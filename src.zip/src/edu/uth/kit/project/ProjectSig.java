package edu.uth.kit.project;

public class ProjectSig extends ProjectZta {

	public ProjectSig(String inputFileName) {
		super(inputFileName);
	}
	public ProjectSig(String projectFileName, int iId, int iUnit, int fileType, String folderName) {
		super(projectFileName, iId, iUnit, fileType, folderName);
	}

}
