package edu.uth.app.component;


public interface FileMenuListener {
public void fileSelected( FileMenuEvent e );
}
