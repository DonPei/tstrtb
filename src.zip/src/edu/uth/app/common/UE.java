package edu.uth.app.common;

public enum UE {
PENDING,
ACTIVE,
INACTIVE,
DELETED;
}
