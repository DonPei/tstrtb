/** General utility classes related to Swing. */
package edu.uth.swing.ui;
